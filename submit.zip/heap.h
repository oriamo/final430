#include <inttypes.h>

extern int64_t heap[];
extern int from_side;

extern char type[];

// in words
#define heap_size 1001
